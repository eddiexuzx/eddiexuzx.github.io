function [loss,grads,inf]=sigmomod(params,xr,yr,xv,yv,xe,ye,opt)
    
    lambda = opt.lambda;
    sigmo = opt.sigmo;

    L = mat(params(1:end-1));
    const = params(end);
    
    %compute a new whole kernel, train & val
    Kall = compute_kernel(xr,[xr,xv],L,const);   %kernel with slack
    Kder = compute_kernel(xr,[xr,xv],L,const,1); %regular kernel

    %run svm to get alpha, b
    [alpha,b] = learn(Kall,yr,opt,const);

    [rxr,cxr] = size(xr);
    I = eye(rxr);
    Isig = I./sigmo;

    %loss
    loss = getlost(xv,yv,alpha,b,Kder,opt);
    loss = loss+lambda*trace((L-Isig)'*(L-Isig)) + lambda*((const-opt.const)^2);

    %have the new alpha and loss, do the test
    %only do gradient and test if minimize asks me
    if nargout>1
        [gradL,gradC] = kgrad(xr,xv,yv,L,const,alpha,b,Kall,Kder,opt);
        gradL = gradL + 2*lambda*(L-Isig); 
		gradC = gradC + 2*lambda*(const-opt.const);

        %gradient
        grads = [vec(gradL);gradC];
    end
    
    inf.alpha = alpha;
    inf.b = b;
    inf.Kder = Kder;
end    
    


function loss = getlost(xv,yv,alpha,b,Kder,opt)

[rxv,cxv] = size(xv);

loss = 0;
for j=1:cxv
  	
	%use the regular kernel
    K = Kder(:,opt.tr+j);
    inner = alpha'*K+b; 
    loss = loss + 1/(1+exp(opt.coeff*inner*yv(j)));
end

end




%% gradient kernel function
function [gradL,gradC] = kgrad(xr,xv,yv,L,const,alpha,b,Kall,Kder,opt)

	[rxr,cxr] = size(xr);
	[rxv,cxv] = size(xv);

	sumgradL = 0;
	sumgradC = 0;

	[d,ddd] = size(L);

	% get the support SVs
	sv = find(alpha~=0);
	
	% prepar the first part, derivative of sigmoid function
	regular_kernel = alpha'*Kder(:,opt.tr+1:end);
	z = (regular_kernel+b).*yv'*opt.coeff;
	firstpart = -exp(z)./((1+exp(z)).^2).*yv'*opt.coeff;
	firstpartb = sum(firstpart);
	firstparta = repmat(firstpart,length(sv),1);
	firstparta = firstparta.*Kder(sv,opt.tr+1:end);

	% precompute the InvH*alpha,b, can't do this, coz (InvH*htop)'!=(InvH*htop)
	% precompute InvH, [alpha;b], H, dalpha2dC, dbias2dC
	[InvH,alphab,H,atoc,btoc] = precompute(const,alpha,b,opt,Kall,sv);

	r = length(sv);
	xsv = xr(:,sv);
	dsqr = d*d;

	Kmul=-InvH(:,1:end-1)*sum(firstparta,2);
	bmul=-InvH(:,end);
	MM=[Kmul bmul];

	[atolpart,btolpart]=alphalcp2qk(H,L,xsv,r,alphab,MM);

	abtolpart = atolpart+btolpart*firstpartb;

	% compute kernel to L
	for j=1:cxv
    	% construct substr
    	substr = [xr,xv(:,j)];
    	weight = Kder(:,opt.tr+j).*alpha;
    	m = [1:cxr]; n = (cxr+1)*ones(1,cxr);
    	outprod = SODW(substr,m,n,weight');
    	inner = -L*outprod;
        
    	% derivative of alpha and b to C
    	initksv = Kder(sv,opt.tr+j);
    	innerC = btoc + initksv'*atoc;
        
    	% add them up
    	sumgradL = sumgradL + firstpart(j) * inner;
    	sumgradC = sumgradC + firstpart(j) * innerC;    
	end
	gradL = sumgradL+abtolpart;
	gradC = sumgradC;
end



function [InvH,alphab,H,atoc,btoc] = precompute(const,alpha,b,opt,Kall,sv)

Q = Kall(1:opt.tr,1:opt.tr);

%only take SVs
alpha = alpha(sv);

ksv = Q(sv,sv);

H = ksv;
H(end+1,:) = 1;               
H(:,end+1) = 1;
H(end,end) = 0;

InvH = inv(H);
alphab = [alpha;b];

htoc = -exp(-const)*eye(size(ksv));
atoc = -InvH(:,1:end-1)*(htoc*alpha);
btoc = atoc(end);
atoc = atoc(1:end-1);

end


function atoleach = alphal(InvH,alphab,H,L,xr,r,k,l,htol)

% the most intensive part, doing it in C
% for i = 1:r
%     for j=1:r
%         htol(i,j) = -H(i,j)*(L(k,:)*(xr(:,i)-xr(:,j)))*(xr(l,i)-xr(l,j));
%     end
% end

% c code
htol3 = alphalcp3q(H,L,xr,r,k,l);
htol2 = alphalcp2(H,L,xr,r,k,l);
no=norm(htol3-htol2);
if 1
	disp(no)
end;

atoleach = -InvH*(htol2*alphab);
end





% Olivier's learn code
function [alpha,b] = learn(Kall,Y,opt,const)

    C = const;
% Do the actual learning (SVM or kernel ridge regression)
  K = Kall(:,1:opt.tr);
% K = exp(-.5.*distance(X',X'));
  svset = 1:length(Y);
  old_svset = [];
  iter = 0;
  itermax = 20;
  
  % If the set of support vectors has changed, we need to
  % reiterate. Note that for regression, all points are support
  % vectors and there is only one iteration.
  while ~isempty(setxor(svset,old_svset)) & (iter<itermax)
    old_svset = svset;
    H = K(svset,svset);
    H(end+1,:) = 1;                 % To take the bias into account
    H(:,end+1) = 1;
    H(end,end) = 0;
    % Find the parameters
    par = H\[Y(svset);0];
    alpha = zeros(length(Y),1);
    alpha(svset) = par(1:end-1)';
    b = par(end);
    % Compute the new set of support vectors

      % Compute the outputs by removing the ridge in K
      out = K*alpha+b - alpha/exp(C); 
      svset = find(Y.*out < 1);

    iter = iter + 1;
  end;
  if iter == itermax
    warning('Maximum number of Newton steps reached');
  end
end
