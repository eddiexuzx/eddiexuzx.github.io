% load your data
load data/haberman.mat

% add path to svm_cv
addpath('./svm_cv');

% compile C++ file
mex alphalcp2qk.c
mex SODW.c

% train & test 80/20
rand('seed',1);
itr=ismember(1:length(y),randsample(1:length(y),ceil(0.8*length(y))));
xr = x(:,itr);
yr = y(itr);
xe = x(:,~itr);
ye = y(~itr);

% normalize data
[xr,xe]=preprocess(xr,xe);

% cross-validation results
acc_cv = svm_cv_module(xr,yr,xe,ye,1);

% SVML result
acc_res = minimizemetric(xr,yr,xe,ye,100,15);

fprintf('Cross Validation Accuracy: %f\n', acc_cv);
fprintf('SVML Accuracy: %f\n', acc_res);
