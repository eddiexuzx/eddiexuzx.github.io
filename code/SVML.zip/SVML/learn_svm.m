
function [alpha,b] = learn_svm(K,Y,const)

    C = const;
% Do the actual learning (SVM or kernel ridge regression)
% K = exp(-.5.*distance(X',X'));
  svset = 1:length(Y);
  old_svset = [];
  iter = 0;
  itermax = 20;
  
  % If the set of support vectors has changed, we need to
  % reiterate. Note that for regression, all points are support
  % vectors and there is only one iteration.
  while ~isempty(setxor(svset,old_svset)) & (iter<itermax)
    old_svset = svset;
    H = K(svset,svset);
    H(end+1,:) = 1;                 % To take the bias into account
    H(:,end+1) = 1;
    H(end,end) = 0;
    % Find the parameters
    par = H\[Y(svset);0];
    alpha = zeros(length(Y),1);
    alpha(svset) = par(1:end-1)';
    b = par(end);
    % Compute the new set of support vectors

      % Compute the outputs by removing the ridge in K
      out = K*alpha+b - alpha/exp(C); 
      svset = find(Y.*out < 1);

    iter = iter + 1;
  end;
  if iter == itermax
    warning('Maximum number of Newton steps reached');
  end
end