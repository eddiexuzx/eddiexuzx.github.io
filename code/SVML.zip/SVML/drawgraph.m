function drawgraph(loss,i,maxiter,C,num)

global trainerr;
global validerr;
global testerr;

if(i==1)
    figure
    base = [0:maxiter];
    subplot(3,1,1); 
    plot(base,0,'-w','linewidth',1);
    hold on;
    plot(i-1,loss,'m.','MarkerSize',20,'erasemode','none');
    text(.5,loss-.1,0,'Loss','Color','m','fontsize',16);
    
    subplot(3,1,3); 
    hold on
    plot(base,0,'-w','linewidth',1);
    % bar(i-1,exp(C),.5,'c');

    subplot(3,1,2); 
    hold on
    plot(base,0,'-w','linewidth',1);
        
    text(.5,trainerr(i)-.001,0,'train','Color','red','fontsize',12);
    text(.5,testerr(i)-.001,0,'test','Color','green','fontsize',12);
    text(.5,validerr(i)-.001,0,'val','Color','blue','fontsize',12);
else

    subplot(3,1,1);
    hold on    
    plot(i-1,loss(i),'m.','MarkerSize',20,'erasemode','none');

    subplot(3,1,3);
    hold on
	if(i-1~=maxiter)
    	bar(i-1,exp(C),.5,'c');
    end

    subplot(3,1,2);
    hold on    
    plot([i-2,i-1],[trainerr(i-1),trainerr(i)],'r-','erasemode','none','LineWidth',3);
    plot([i-2,i-1],[validerr(i-1),validerr(i)],'b-','erasemode','none','LineWidth',3);
    plot([i-2,i-1],[testerr(i-1),testerr(i)],'g-','erasemode','none','LineWidth',3);
   	
	if(nargin==5)
		text(i-2+.3,validerr(i)+.05,0,num2str(num), 'fontsize',10, 'Color','blue');
    drawnow;
end

end

