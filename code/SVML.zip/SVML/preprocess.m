function [xTr,xTe,u,m]=preprocess(xTr,xTe,pvar);
% function [xTr,xTe,u,m]=preprocess(xTr,xTe,pvar);
%
% Preproces the data to make the training features have zero-mean and
% standard-deviation 1
%
% output:
% xTr - pre-processed training data 
% xTe - pre-processed testing data
% 
% u,m - any other data should be pre-processed by x-> u*(x-m)
%

%%<<kqw
if nargin<3,pvar=0.99;end;
m=mean(xTr,2);
xTr=xTr-repmat(m,1,size(xTr,2));
xTe=xTe-repmat(m,1,size(xTe,2));

st=std(xTr');
u=diag(1./st);
u(find(st<eps),:)=[];
xTr=u*xTr;
xTe=u*xTe;
