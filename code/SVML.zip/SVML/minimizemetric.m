function [algoresult,allpreds] = minimizemetric(xr,yr,xe,ye,lambda,iter,sig,c)



%% prepare data
% test data
testxr = xr;
testyr = yr;

n = length(testyr);
nv = round(n/2);
nve = round(nv/2);

xr = testxr(:,1:end-nv);
yr = testyr(1:end-nv);

xv = testxr(:,end-nv+1:end-nve);
yv = testyr(end-nv+1:end-nve);

xve = testxr(:,end-nve+1:end);
yve = testyr(end-nve+1:end);

opt.nv = nv-nve;
opt.ne = nve;
opt.tr = n-nv;

%% setup the params 
% kernel
if(nargin==8)
	c = log(c);	
else
	c = log(1);
  	% sig = .3*var(testxr');
 sig = var(testxr');
	sig = sum(sig);
	sig = sig^.5;
	% this is essentially, the sqrt of dimensions
    % keyboard
end


%% initial vars
maxiter = iter;
opt.const = c;
opt.maxiter = iter;
opt.lambda = lambda;  %for ||M-I||
opt.sigmo = sig;
opt.coeff = 5;

%L is set to I/sigmo
[rxr, cxr] = size(xr);
L = eye(rxr)./sig;
C = c;


%call the minimize function
params = [vec(L);C];

% train the val/val and test on val/test
[tempparams,fx,step] = minimize(params,'sigmomod',maxiter,0,xr,yr,xv,yv,xve,yve,opt);
% err=checkgradvector('sigmomod',tempparams,1e-5,xr,yr,xv,yv,xe,ye,opt);disp(err);keyboard; 

% train again on the val/val+val/test and test on test
opt.nv = nv;
opt.tr = n-nv;
[tempparams,fx,step,result,allpreds] = minimize(params,'sigmomod',step,1,xr,yr,[xv,xve],[yv;yve],xe,ye,opt);
% [params,fx,step,result,allpreds] = minimize(params,'sigmomod',step,1,xr,yr,xv,yv,xve,yve,opt);


algoresult = result;


end



