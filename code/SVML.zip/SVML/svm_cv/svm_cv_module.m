
%% svm module
function [resultcv,preds,sig,C] = svm_cv_module(xr,yr,xe,ye,folds)

[sig,C] = svm_cross(xr,yr,folds)

[resultcv,preds] = svm_test(xr,yr,xe,ye,sig,C);

end


%% svm cross
function [sig,c] = svm_cross(xr,yr,folds)
% load balance

xtr = xr;
ytr = yr;

[d n] = size(xtr);

sigma = [1,d/4,d/2,d,d*2];
sigma = sigma*.3;
sigma = sigma.^0.5;
const = [0.01,0.1,1,10,100];


k = folds;

ind = crossvalind('Kfold', n, k);
count = 0;
result = zeros(length(sigma),length(const));

for i=1:length(sigma)
    for j=1:length(const)
        params = [log(sigma(i)),log(const(j))];
		% cross validation
		result(i,j) = 0;
		for t=1:k
            count = count+1;
			fprintf('%d\r',count);
            test = (ind==t); train = ~test;
            
            if k==1
                train=ismember(1:length(ytr),randsample(1:length(ytr),ceil(0.8*length(ytr))));
                test=~train;
            end
        
			cvxte = xtr(:,test);
			cvxtr = xtr(:,train);
			cvyte = ytr(test);
			cvytr = ytr(train);
			
			%learn the model
			[alpha, b] = learn(cvxtr',cvytr,params,1);
			
			%test
			Kt = compute_kernel(cvxte',cvxtr',sigma(i));
			preds = sign(Kt*alpha+b);
        	result(i,j) = result(i,j) + analyze('acc',cvyte,preds);
        end
        result(i,j) = result(i,j)/k;
    end
end

[i,j] = find(result==max(max(result)));
sig = sigma(i);
c = const(j);

sig = sig(1);
c = c(1);
end



%% svm test
function [result,preds] = svm_test(xr,yr,xe,ye,sig,c)           

    params = [log(sig),log(c)];
    
    %learn the model
	[alpha, b] = learn(xr',yr,params,1);
		
	%test
	Kt = compute_kernel(xe',xr',sig);
	preds = sign(Kt*alpha+b);
    result = analyze('acc',ye,preds);
end
   

            
%% compute kernel
function K = compute_kernel(X,Y,sig)
  % Compute the RBF kernel matrix
    X = X / sig;
    Y = Y / sig;


  normX = sum(X.^2,2);
  normY = sum(Y.^2,2);

  K = exp(-0.5*(repmat(normX ,1,size(Y,1)) + ...
                repmat(normY',size(X,1),1) - 2*X*Y'));
end        

