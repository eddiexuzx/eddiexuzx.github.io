function [alpha,b] = learn(X,Y,param,classif)
% Do the actual learning (SVM or kernel ridge regression)
  K = compute_kernel(X,[],param);
  svset = 1:length(Y);
  old_svset = [];
  iter = 0;
  itermax = 20;
  
  % If the set of support vectors has changed, we need to
  % reiterate. Note that for regression, all points are support
  % vectors and there is only one iteration.
  while ~isempty(setxor(svset,old_svset)) & (iter<itermax)
    old_svset = svset;
    H = K(svset,svset);
    H(end+1,:) = 1;                 % To take the bias into account
    H(:,end+1) = 1;
    H(end,end) = 0;
    % Find the parameters
    par = H\[Y(svset);0];
    alpha = zeros(length(Y),1);
    alpha(svset) = par(1:end-1)';
    b = par(end);
    % Compute the new set of support vectors
    if classif
      % Compute the outputs by removing the ridge in K
      out = K*alpha+b - alpha/exp(param(end)); 
      svset = find(Y.*out < 1);
    end;
    iter = iter + 1;
  end;
  if iter == itermax
    warning('Maximum number of Newton steps reached');
  elseif classif & any(alpha.*Y<0)
    warning('Bug in learn');
  end;
    
function K = compute_kernel(X,Y,param,diff)
% Compute the RBF kernel matrix between  [X;Y] and X.
% if diff is given, compute the derivate of the kernel matrix
%  with respect to the diff-th parameter of param.  
  
  global K0   % Keep the kernel matrix in memory; we'll need to
              % compute the derivatives.
  
  Z = [X; Y];
  Y = X; X = Z; clear Z;
  ridge = exp(-param(end));
  
  if nargin<4    % Compute the kernel matrix
    
    % Divide by the length scales
    if length(param)==2
      X = X * exp(-param(1));
      Y = Y * exp(-param(1));
    else
      X = X .* repmat(exp(-param(1:end-1)'),size(X,1),1);
      Y = Y .* repmat(exp(-param(1:end-1)'),size(Y,1),1);
    end;
    
    normX = sum(X.^2,2);
    normY = sum(Y.^2,2);
    
    K0 = exp(-0.5*(repmat(normX ,1,size(Y,1)) + ...
                  repmat(normY',size(X,1),1) - 2*X*Y'));
    K = K0 + eye(size(K0))*ridge;

  else  % Compute the derivate
    if diff == length(param)    % With respect to log(C)
      K = - ridge*eye(size(K0));
    elseif length(param) == 2   % With respect to spherical log(sig)
      K = -2*K0.*log(K0+eps);
    else                        % With respect to log(sig_i)
      dist = repmat(X(:,diff),1,size(Y,1)) - ...
             repmat(Y(:,diff)',size(X,1),1);
      K = K0 .* (dist/exp(param(diff))).^2;
    end;
  end;