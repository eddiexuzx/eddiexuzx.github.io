This is the SVML code in matlab format.
It won't really work for data set that have high dimensional features, p>>n
Please run example.m 

If mex error occurs, please run:
mex -setup 
in matlab, and select a gcc compiler.


