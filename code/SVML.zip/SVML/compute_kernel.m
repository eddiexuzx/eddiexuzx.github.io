function K = compute_kernel(X,Y,L,C,diff)
% Compute the RBF kernel matrix between  [X;Y] and X.
% if diff is given, compute the derivate of the kernel matrix
%  with respect to the diff-th parameter of param.  
 
    ridge = exp(-C);
    
    K0 = exp(-.5*distance(L*X,L*Y));
    
if (nargin==5)
    K = K0;
else
    K = K0 + eye(size(K0))*ridge;
end
end