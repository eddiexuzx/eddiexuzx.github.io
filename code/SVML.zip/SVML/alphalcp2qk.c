/*
 * =============================================================
 * alphalcp.cu
  
 * input: H,L,xr
 *    curlH: InvH*alpha,b		r+1*r+1
 *	  H : 						r+1*r+1
 *    L : 						d*d
 *	  xr: 						data, d*n
 *	  htol:  H to each L		r+1*r+1
 *    r:     size of curlH		1
 *    k:	 rth row of L		1
 *	  l:	 lth column of L	1
 * output: 
 *	  htol:	all a,b to L_kl r+1*r+1
 * 
 * copyright 2010 Zhixiang Xu
 * =============================================================
 */

#include <mex.h>


/* host code, function */
void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
	double *H, *L, *xr, *alphab,*INVH,*kderiv,*bderiv;
	int r, k, l, d, rp, dn,i,j,s;
	double *addrj, *addri, Kdev,bdev,temp, LC1, LC2, LC3, temp2;
	
	
	H = mxGetPr(prhs[0]);
	L = mxGetPr(prhs[1]);
	alphab = mxGetPr(prhs[4]);
	INVH = mxGetPr(prhs[5]);
	xr = mxGetPr(prhs[2]);
	d = mxGetM(prhs[2]);
	dn = mxGetN(prhs[2]);


	
	r = (int)(*(mxGetPr(prhs[3])));
	
	rp = r+1;
	plhs[0]=mxCreateDoubleMatrix(d,d,mxREAL);
	kderiv = mxGetPr(plhs[0]);
	plhs[1]=mxCreateDoubleMatrix(d,d,mxREAL);
	bderiv = mxGetPr(plhs[1]);

	for(k=0;k<d*d;k++){
		kderiv[k] = 0.0;	
		bderiv[k] = 0.0;	
	}
 	 	
	for(i=0;i<r;i++){	
			addri = xr+i*d;
			for(j=0;j<i;j++){
				addrj = xr+j*d;
				LC1 = alphab[j]*INVH[i]+alphab[i]*INVH[j];
				LC2 = alphab[j]*INVH[i+rp]+alphab[i]*INVH[j+rp];
				LC3 = *(H+rp*j+i);
				for(k=0; k<d; k++){
				  temp = 0.0;
				  for(s=0;s<d;s++) temp += (addri[s]-addrj[s]) * L[k+s*d];			
				  temp2 = 0.0;
				  for(l=0; l<d; l++){
				    temp2 = -temp*(addri[l]-addrj[l])*(LC3);
				    kderiv[(l*d)+k] += temp2*(LC1);
				    bderiv[(l*d)+k] += temp2*(LC2);
				  }
				}
			}
		}


  	
}
	
	
	
	
