function [loss,grad,gatingloss]=inner_loss_grad(Wttheta, data, pars, tree, t, Wall, lambda, patht, leftleaves, rightleaves, idx_w, sigmas, idx_sigmas, keta, idx_keta, etas, bestrho, Tree, lastnode)
% INNER_LOSS_GRAD Compute loss and gradient of an inner node t
%
% INPUTS
%	Wttheta - parameters of current node t and threshold theta (1,d+1)
%	data - a struct containing all data (see runYahoo.m for an example)
%	pars - a struct of parameter settings
%	tree - a struct of CSTC information
%	t - index of node t being optimized
%	Wall - parameter matrix of all nodes
%	lambda - accuracy/cost trade-off parameter
%	patht - indices of paths that node t is in
%	leftleaves - path starting with left (upper) child of node t
%	rightleaves - path startin with right (lower) child of node t
%	idx_w - indicator vector of non-zero elements of Wt
%	sigmas - auxiliary variable for feature cost term for node t
%	idx_sigmas - indicator vector of non-zero sigmas for node t
%	keta - auxiliary variable for evaluation cost term for node t
%	idx_keta - indicator vector of non-zero ketas for node t
%	etas - auxiliary variable for l1 term, node t
%	bestrho - best l1-regularization trade-off
%	Tree - tree information matrix
%	lastnode - the leaf nodes of all paths containing node t
%
% OUTPUTS
%	loss - objective value
%	grad - gradient of objective
%	gatingloss - objective without cost
%	gradloss - UNNECESSARY
%	gradreg - UNNECESSARY
	
	Wt = Wttheta(1:end-1)';
	thetat = Wttheta(end);
	
	threshold = 1e-03;
	
	% sigmoid function
	sig=@(z) 1./(1+exp(-pars.sigwidth*z));
	sigp=@(sz) sz.*(1-sz) * pars.sigwidth;
	
	[d,n] = size(data.xtr);
		
	% marginal probability of any input reaching node t
	dk = sum(prod(tree.nodeprob_sepa(tree.parentnodes(t,:),:),1).*pars.wtra)/sum(pars.wtra); % TODO: remove
	
	% RISK TERMS %
	% ---------- %
	
	% self loss, node t
	selfloss = sum((data.ytr - Wt*data.xtr).^2 .* prod(tree.nodeprob_sepa(tree.parentnodes(t,:),:),1).*pars.wtra/sum(pars.wtra));
	selflossgrad = -2 * (data.ytr - Wt*data.xtr) .* (prod(tree.nodeprob_sepa(tree.parentnodes(t,:),:),1).*pars.wtra/sum(pars.wtra)) * data.xtr';
	
	% --- debugging --- %
	if nargout == 3
		loss = 0; grad =0;
		gatingloss = selfloss + bestrho * sum(abs(Wt(1:end-1)));
		return;
	end
	
	% loss and gradient of Wt through probability of going to child nodes
	wtsig = sig(Wt*data.xtr - thetat);
	leftprob = wtsig;
	leftprobgrad = sigp(wtsig);
	rightprob = 1-wtsig;
	rightprobgrad = -sigp(wtsig);
	
	gradnodeprob_sepa = tree.nodeprob_sepa;
	
	% adjust probability & gradient of probability of reaching child nodes
	tree.nodeprob_sepa(Tree(t,3),:) = leftprob;
	tree.nodeprob_sepa(Tree(t,4),:) = rightprob;
	gradnodeprob_sepa(Tree(t,3),:) = leftprobgrad;
	gradnodeprob_sepa(Tree(t,4),:) = rightprobgrad;
	
	% for all descendants of left (upper) child, compute their risk and gradient, as it is affected by Wt through
	% the traversal probability: sig(Wt*xtr - thetat) (see eq. (18) in Supplementary Material)
	preleft = 0; preright = 0; gradleftpart = 0; gradrightpart = 0;
	if isempty(leftleaves)
		preleft = 0; gradleft = 0;
	else
		for leftind = leftleaves
			preleft = preleft + (data.ytr - Wall(leftind,:)*data.xtr).^2 .* prod(tree.nodeprob_sepa(tree.parentnodes(leftind,:),:),1).*pars.wtra/sum(pars.wtra);
			if nargout > 1
				gradleftpart = gradleftpart + (data.ytr - Wall(leftind,:)*data.xtr).^2 .* prod(gradnodeprob_sepa(tree.parentnodes(leftind,:),:),1).*pars.wtra/sum(pars.wtra);
			end
		end
		gradleft = gradleftpart * data.xtr';		% (1,d)
	end
	
	% for all descendants of right (lower) child, compute risk and gradient, as above
	if isempty(rightleaves)
		preright = 0; gradright = 0;
	else
		for rightind = rightleaves
			preright = preright + (data.ytr - Wall(rightind,:)*data.xtr).^2 .* prod(tree.nodeprob_sepa(tree.parentnodes(rightind,:),:),1).*pars.wtra/sum(pars.wtra);
			if nargout > 1
				gradrightpart = gradrightpart + (data.ytr - Wall(rightind,:)*data.xtr).^2 .* prod(gradnodeprob_sepa(tree.parentnodes(rightind,:),:),1).*pars.wtra/sum(pars.wtra);
			end
		end
		gradright = gradrightpart * data.xtr';	% (1,d)
	end
	
	% sum over all data points
	leftloss = sum( preleft );
	rightloss = sum( preright );
	gradleft_theta = -sum(gradleftpart);	% negative because the gradient of theta
	gradright_theta = -sum(gradrightpart);
	
	% COST TERMS %
	% ---------- %
	
	% indicator variables for the descendants of left (upper) and right (lower) children
	if isempty(leftleaves) 
		dsleft = zeros(1,size(tree.descendants,2));
	else
		dsleft = (tree.descendants(Tree(t,3),:)~=0); 
	end
	if isempty(rightleaves)
		dsright = zeros(1,size(tree.descendants,2));
	else
		dsright = (tree.descendants(Tree(t,4),:)~=0);
	end
	
	% get parents of node t
	temp = find(tree.parentnodes(t,:));
	temp = temp(1:end-1);

	% these are the parent parts of the constant terms in the cost (see eq. (18) in Supplementary Material)
	if isempty(temp);
		parentstreenorm = zeros(size(Wall,2)-1,1);
		parentsfeatnorm = zeros(size(data.F,1),1);
	else
		parentstreenorm = sum(Wall(temp,1:end-1)'.^2,2);	% tx1
		parentsfeatnorm = sum((data.F*Wall(temp,1:end-1)').^2,2);	% dx1
	end
	
	ind = 1;
	mixedpathfeat = 0; mixedpathfeatgrad = 0; mixedpathtree=0; mixedpathtreegrad=zeros(1,d); mixedpathtreegrad_theta=0; mixedpathfeatgrad_theta=0;
	for tt = patht'
		% identify last node
		if (Tree(lastnode(ind),3)==0 & Tree(lastnode(ind),4)==0)	% if last node has no child
			% marginal probability of any input reaching node t
			dl = sum(prod(tree.nodeprob_sepa(tree.parentnodes(lastnode(ind),:),:),1).*pars.wtra)/sum(pars.wtra);
			% gradient of marginal probability of any input reaching node t
			ddtemp = prod(gradnodeprob_sepa(tree.parentnodes(lastnode(ind),:),:),1);
			ddl = ddtemp.*pars.wtra/sum(pars.wtra) * data.xtr';			% xtr because gradient of Wt
			ddl_theta = -sum(ddtemp.*pars.wtra/sum(pars.wtra));		% negative because gradient of theta
		else if Tree(Tree(lastnode(ind),3),1)==0					% if child of last node is a predictive node
				dl = sum(prod(tree.nodeprob_sepa(tree.parentnodes(lastnode(ind),:),:),1).*tree.nodeprob_sepa(Tree(lastnode(ind),3),:).*pars.wtra)/sum(pars.wtra);
				ddtemp = prod(gradnodeprob_sepa(tree.parentnodes(lastnode(ind),:),:),1).*gradnodeprob_sepa(Tree(lastnode(ind),3),:);
				ddl = ddtemp.*pars.wtra/sum(pars.wtra) * data.xtr';
				ddl_theta = -sum(ddtemp.*pars.wtra/sum(pars.wtra));
			else 
				dl = sum(prod(tree.nodeprob_sepa(tree.parentnodes(lastnode(ind),:),:),1).*tree.nodeprob_sepa(Tree(lastnode(ind),4),:).*pars.wtra)/sum(pars.wtra);
				ddtemp = prod(gradnodeprob_sepa(tree.parentnodes(lastnode(ind),:),:),1).*gradnodeprob_sepa(Tree(lastnode(ind),4),:);
				ddl = ddtemp.*pars.wtra/sum(pars.wtra) * data.xtr';
				ddl_theta = -sum(ddtemp.*pars.wtra/sum(pars.wtra));
			end
		end	
		
		% indicator vector of descendant nodes along a path through node t
		pathds = ((tree.allpath(tt,:) == [dsleft | dsright]) & tree.allpath(tt,:)~=0);
		
		% feature cost auxiliary variable (constant term + variable term + constant term)
		newsigma = parentsfeatnorm + data.F.^2*(Wt(1:end-1)').^2 + sum(data.F.^2*(Wall(pathds,1:end-1)').^2,2);
		% evaluation cost auxiliary variable (constant term + variable term + constant term)
		newketa = parentstreenorm + (Wt(1:end-1)').^2 + sum((Wall(pathds,1:end-1).^2)',2);
		% these are the variational subsitution for the feature cost and evaluation cost via Lemma 1 (eq. 7 in main paper)
		% they are written out in eq. 17 in the Supplementary Material
		mixedpathfeat = mixedpathfeat + lambda * dl^2 * 0.5*data.cost(logical(idx_sigmas(:,ind)))./sigmas(logical(idx_sigmas(:,ind)),ind)'*(newsigma(logical(idx_sigmas(:,ind))));
		mixedpathtree = mixedpathtree + lambda * dl^2 * 0.5*(sum(newketa(logical(idx_keta(:,ind)))./keta(logical(idx_keta(:,ind)),ind)));

		if nargout > 1
			% feature norms
			% feature cost / feature cost auxiliary variable
			temp = data.cost(logical(idx_sigmas(:,ind)))./sigmas(logical(idx_sigmas(:,ind)),ind)';
			% feature cost * F^2 / feature cost auxiliary variable
			tmpf2idxs = temp * data.F(logical(idx_sigmas(:,ind)),:).^2;
			% feature cost * F^2 * W(path after t)^2 / feature cost auxiliary variable
			tmpf2wa2idxs = tmpf2idxs*(Wall(pathds,1:end-1)').^2;
			% feature cost * F^2 * Wt^2 / feature cost auxiliary variable
			tmpf2w2idxs = tmpf2idxs*(Wt(1:end-1)'.^2);
			
			mixedpathfeatgrad = mixedpathfeatgrad + lambda * sum(temp * parentsfeatnorm(logical(idx_sigmas(:,ind)))) * dl * ddl + ...
				lambda * ([dl^2 * tmpf2idxs .* Wt(1:end-1), 0] + ...																
				tmpf2w2idxs*dl*ddl + ... 																							
				sum(tmpf2wa2idxs,2) * dl * ddl);																					

			% tree norms
			% 1 / evaluation cost auxiliary variable
			temp2 = 1./keta(logical(idx_keta(:,ind)),ind);
			% Wt^2 / evaluation cost auxiliary variable
			tmpw2idxk = temp2' * Wt(logical(idx_keta(:,ind)))'.^2;
			% W(path after t)^2 / evaluation cost auxiliary variable
			tmpwa2idxk = temp2' * (Wall(pathds,logical(idx_keta(:,ind))).^2)';
			% lambda * (prob reaching t)^2 * Wt / evaluation cost auxiliary variable
			aa = lambda * temp2' * dl^2 .* Wt(logical(idx_keta(:,ind)));
			mixedpathtreegrad(logical(idx_keta(:,ind))) = mixedpathtreegrad(logical(idx_keta(:,ind))) + aa;
			mixedpathtreegrad = mixedpathtreegrad + lambda * temp2' * parentstreenorm(logical(idx_keta(:,ind))) * dl * ddl + ...	% path before t
				lambda * (tmpw2idxk * dl * ddl + ...																				% node t
				sum(tmpwa2idxk,2) * dl * ddl);																						% paths after t
			
			% both theta norms
			mixedpathfeatgrad_theta = mixedpathfeatgrad_theta + lambda * temp * parentsfeatnorm(logical(idx_sigmas(:,ind))) * dl * ddl_theta + ...	% paths after t
				lambda * (tmpf2w2idxs*dl*ddl_theta + ...																							% node t
				sum(tmpf2wa2idxs,2) * dl * ddl_theta);																								% paths after t
			mixedpathtreegrad_theta = mixedpathtreegrad_theta + lambda * temp2' * parentstreenorm(logical(idx_keta(:,ind))) * dl * ddl_theta + ...	% paths after t
				lambda * (tmpw2idxk * dl * ddl_theta + ...																							% node t
				sum(tmpwa2idxk,2) * dl * ddl_theta);																								% paths after t
		end
		ind = ind+1;
	end
	
	% mixed norm l1 loss for all descedents
	lossl1 = 0.5 * bestrho * sum(Wt(idx_w(1:end-1)).^2./etas);
	if nargout > 1
		gradlossl1 = [bestrho * Wt(idx_w(1:end-1))./etas,0];
	end

	% total loss
	loss = selfloss + leftloss + rightloss + lossl1 + mixedpathfeat + mixedpathtree;
	
	if nargout > 1
		% total grad W
		grad = selflossgrad + gradleft + gradright + mixedpathfeatgrad + mixedpathtreegrad;
		grad(idx_w) = grad(idx_w) + gradlossl1;

		% total grad theta
		gradtheta = gradleft_theta + gradright_theta + mixedpathfeatgrad_theta + mixedpathtreegrad_theta;
		
		gradoriginal = grad;
		grad(:) = 0;
		grad(idx_w) = gradoriginal(idx_w);
	end
	
	if size(grad,2) > size(grad,1) 
		grad = grad';
	end
	
