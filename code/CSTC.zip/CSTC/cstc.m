function [results, tree, Tree, W] = cstc(data, varargin)
	% CSTC Implements the paper "Cost-Sensitive Tree of Classifiers", Xu et al. 2013 ICML.
	%  	   Extra documentation is added compared to the original implementation.
	%
	% function [tst_cost, tst_ndcg, tst_mse] = cstc(data,'Parameter1',Value1,'Parameter2',Value2,...);
	%
	% INPUTS
	%	data - a struct containing all data (see demo_yahoo.m for an example)
	% OTHER PARAMETERS:
	% 	lambda0 - initial setting of trade-off hyperparameter lambda
	%	keep - the proportion of inputs that go to an upper child node in the tree
	%	depth - the maximum depth of the tree
	%	rank_flag - a flag describing whether we are dealing with a ranking data set
	%	rhos - a list of grid search values for hyperparameter rho (to be multiplied by lambda0)
	%
	% OUTPUTS
	%	results - a struct containing all CSTC results
	%	tree - a struct containing CSTC tree annotation information
	%	Tree - CSTC tree
	%	W - weights of nodes in CSTC
		
	fprintf('CSTC version 1.0\n');
	if(nargin==0)
	 help cstc;
	 return;
	end;
	
	% get size and add bias
	[d,n] = size(data.xtr);
	data.xtr = [data.xtr;ones(1,n)];	
	[d,nval] = size(data.xtv);
	data.xtv = [data.xtv;ones(1,nval)];
	[dd,ntst] = size(data.xte);
	data.xte = [data.xte;ones(1,ntst)];
	
	% set parameters
	pars.lambda0 = 5e-05; % 1e-05*(1.5)^2 % reg for norms
	pars.keep    = 0.5;
	pars.depth   = 10;
	%pars.rank_flag = 1; % means queries are defined in data struct (see demo_yahoo.m for an example)
	pars.method = 'ranking';  % means queries are defined in data struct (see demo_yahoo.m for an example)

	pars.discount = 2;
	pars.rhos = [.2:.1:.9,1:6]; % [.5:.1:.9,1:5] % rho = 1e-09	% reg for orthogonal
	pars.sigwidth = 50;
	pars.wtra = ones(1,n);	% instance-specific weights
	pars.min_nodes = 10;
	pars.prune = 1;
	pars.reopt_maxiter = 3;
	pars.reopt_subiter = 10;
	pars.finetune_maxiter = 1;
	pars.node_eval = 'ndcg';
	pars=extractpars(varargin,pars);
	
	pars.rhos = pars.rhos*pars.lambda0;
	pars.lambdas = pars.lambda0*cumprod([1,1/pars.discount*ones(1,10)])

	sig=@(z) 1./(1+exp(-pars.sigwidth*z));	% sigmoid function


	% initialize results structure
	results.tra_cost = 0; 					% holds the cost of the tree over the training set
	results.totalloss = 0;					% holds the loss of the tree
	results.tra_partition = ones(2^pars.depth-1,n);						% indicator matrix of the nodes the training points visit
	results.tra_preds = zeros(1,n); 									% hold the training predictions
	results.val_partition = ones(2^pars.depth-1,nval);
	results.val_preds = zeros(1,nval);
	results.val_cost = 0;
	results.tst_partition = ones(2^pars.depth-1,ntst);
	results.tst_preds = zeros(1,ntst);
	results.tst_cost = 0;
	
	% tree information
	% probabilities
	tree.nodeprob = ones(2^pars.depth-1,n);				% the probability of each input reaching each node from the root node
	tree.nodeprob_sepa = ones(2^pars.depth-1,n);			% the probability of each input reaching each node from their parent node
	% features
	tree.fnotused = ones(2^pars.depth-1,length(data.cost));	% indicator matrix of features not used at each node
	tree.tnotused = ones(2^pars.depth-1,d);				% indicator matrix of weak learners not used at each node
	tree.newtree = zeros(2^pars.depth-1,1);				% holds the evaluation cost caused by the additional weak learners at each node
	tree.newfeat = zeros(2^pars.depth-1,1);				% holds the feature cost caused by the additional features at each node
	% tree structure
	Tree = zeros(2^pars.depth-1,6); % 1 depth, 2 active, 3 upper child index, 4 lower child index, 5 is leaf node, 6 parent
	Tree(1,1) = 1;
	% tree node weights
	W = ones(2^pars.depth-1,d+1); % including the constant

	disp('##################################initialization##################################');
	tic;
	% some indices
	curdepth = 1; t = 1; curnode = 1;
	count = 0; newchildren = 1;
	nv = 1;
	while curdepth <= pars.depth
		children = newchildren;
		newchildren = [];
		% build both upper and lower children
		for t = children
			% first set these two nodes active
			Tree(t,2) = 1;
	
			% pre-compute
			transxtr = (bsxfun(@times,data.xtr,sqrt(tree.nodeprob(t,:)).*(pars.wtra.^.5)))/sqrt(sum(pars.wtra));
			transytr = data.ytr.*sqrt(tree.nodeprob(t,:)).*(pars.wtra.^.5)/sqrt(sum(pars.wtra));
			transXX = transxtr * transxtr';
			transXY = transxtr * transytr';
			% find all parents of current node t
			pathroot = t;
			tup = t;
			while(tup > 1)
				pathroot = [pathroot,Tree(tup,end)];
				tup = Tree(tup,end);
			end	
			lambda = pars.lambdas(Tree(t,1));

			% tune
			if curdepth == 1
				[W(t,:),bestrho] = tune_init(data, pars, tree, results, transXX, transXY, transytr, transxtr, Tree, t, W(t,:), W, d, pathroot, lambda, curdepth, nval);
				count = count + 1;
				%keyboard
			else
				threshold = 1e-03;
				Wt = W(t,:);	
				% preparation for optimization initialization
				prevloss = inf;
				prev_idxw = ones(1,d+1);
				maxiter = 100;
		
				% solving it using alternating algo.
				i = 1;
				while true
					idx_w = (abs(Wt(1:end-1)) > threshold);
					idx_w = [idx_w,true];
					Wt(~idx_w) = 0;	
					W(t,:) = Wt;

					eta = abs(Wt(idx_w(1:end-1)));
					% dk = [];
					% for k = pathroot
					% 	dk = [dk, (tree.nodeprob(k,:) * pars.wtra')/sum(pars.wtra)];
					% end				
					% keta for the path
					keta = sqrt(sum((W(pathroot,1:end-1)').^2,2));
					idx_keta = keta~=0;	
					% sigma for the path
					sigma = sqrt(sum(data.F.^2*(W(pathroot,1:end-1)').^2,2));
					idx_sig = sigma~=0;	
					expertloss = sum((transytr - Wt*transxtr).^2) + lambda*(data.cost(idx_sig) * sigma(idx_sig) + sum(keta(idx_keta))) + bestrho * sum(abs(Wt(idx_w(1:end-1))));

					% termination criteria
					if i > maxiter
						break;
					end
					if sum(idx_w) == 1
						break;
					end
					if sum(idx_w) <= sum(prev_idxw) & sum(idx_w ~= prev_idxw)/sum(idx_w) < 0.005 & expertloss <= prevloss & (prevloss - expertloss)/expertloss < 1e-05 
						break;
					end
					prev_idxw = idx_w; prevloss = expertloss;	
					
					% closed-form
					Wt_res = (transXX(idx_w,idx_w) + ...
						diag([.5*bestrho*(ones(1,sum(idx_w)-1)./eta),0]) + ...
						0.5*lambda*diag([(1./keta(idx_w(1:end-1)))'+data.cost(idx_sig)./sigma(idx_sig)'*data.F(idx_sig,idx_w(1:end-1)),0]))\(transXY(idx_w)); 
			
					Wt(:) = 0;
					Wt(idx_w) = Wt_res;
					i = i + 1;
				end
				count = count + 1;
			end	
			% statistics
			alltree(t) = sum(W(t,1:end-1)~=0);
			allfeat(t) = sum((data.F*(W(t,1:end-1)~=0)')~=0);
			if curdepth > 1
				tree.newtree(t) = sum((W(t,1:end-1) ~= 0) & (W(Tree(t,end),1:end-1) == 0));
				tree.newfeat(t) = tree.fnotused(t,:) * ((data.F*(W(t,1:end-1)~=0)')~=0);
			else
				tree.newtree(t) = alltree(t); tree.newfeat = allfeat(t);
			end
			
			bn = t;
			% predictions
			% training
			results.tra_preds(logical(results.tra_partition(bn,:))) = W(bn,:)*data.xtr(:,logical(results.tra_partition(bn,:)));
			if strcmp(pars.method,'ranking')%rank_flag
				results.tra_ndcg = ndcg(results.tra_preds,data.traqs,data.ytr,5, 10);
			elseif strcmp(pars.method,'classification')
				tra_p = results.tra_preds;
				tra_p(tra_p >= 0.5) = 1;
				tra_p(tra_p <  0.5) = 0;
				results.tra_err = mean(tra_p ~= data.ytr);
			end
			results.tra_mse = mean((results.tra_preds-data.ytr).^2);
			results.tra_cost = results.tra_cost + sum(results.tra_partition(bn,:))/n * (tree.fnotused(bn,:).*data.cost*((data.F*(W(bn,1:end-1)~=0)')~=0) + tree.tnotused(bn,:)*(W(bn,1:end-1)~=0)'); 	
			% validation
			results.val_preds(logical(results.val_partition(bn,:))) = W(bn,:)*data.xtv(:,logical(results.val_partition(bn,:)));
			%if pars.rank_flag
			%	results.val_ndcg = ndcg(results.val_preds,data.valqs,data.ytv,5, 10);
			%end
			if strcmp(pars.method,'ranking')%rank_flag
				results.val_ndcg = ndcg(results.val_preds,data.valqs,data.ytv,5, 10);
			elseif strcmp(pars.method,'classification')
				val_p = results.val_preds;
				val_p(val_p >= 0.5) = 1;
				val_p(val_p <  0.5) = 0;
				results.val_err = mean(val_p ~= data.ytv);
			end
			results.val_mse = mean((results.val_preds-data.ytv).^2);
			results.val_cost = results.val_cost + sum(results.val_partition(bn,:))/nval * (tree.fnotused(bn,:).*data.cost*((data.F*(W(bn,1:end-1)~=0)')~=0) + tree.tnotused(bn,:)*(W(bn,1:end-1)~=0)'); 	
			% testing
			results.tst_preds(logical(results.tst_partition(bn,:))) = W(bn,:)*data.xte(:,logical(results.tst_partition(bn,:)));
			%if pars.rank_flag
			%	results.tst_ndcg = ndcg(results.tst_preds,data.tstqs,data.yte,5, 10);
			%end
			if strcmp(pars.method,'ranking')
				results.tst_ndcg = ndcg(results.tst_preds,data.tstqs,data.yte,5, 10);	
			elseif strcmp(pars.method,'classification')
				tst_p = results.tst_preds;
				tst_p(tst_p >= 0.5) = 1;
				tst_p(tst_p <  0.5) = 0;
				results.tst_err = mean(tst_p ~= data.yte);
			end
			results.tst_mse = mean((results.tst_preds-data.yte).^2);
			results.tst_cost = results.tst_cost + sum(results.tst_partition(bn,:))/ntst * (tree.fnotused(bn,:).*data.cost*((data.F*(W(bn,1:end-1)~=0)')~=0) + tree.tnotused(bn,:)*(W(bn,1:end-1)~=0)'); 

			Tree(bn,2) = sum(results.tst_partition(bn,:))/ntst * (tree.fnotused(bn,:).*data.cost*((data.F*(W(bn,1:end-1)~=0)')~=0) + tree.tnotused(bn,:)*(W(bn,1:end-1)~=0)'); 
			fprintf('node: %d, depth: %d, nv: %d, tra_cost: %f, tra_mse: %f, val_cost: %f, val_mse: %f, tst_cost: %f, tst_mse: %f, trees: %d, feat: %d, new trees: %d, new feat: %d\n',...
				bn, Tree(bn,1), nv-1, results.tra_cost, results.tra_mse, results.val_cost, results.val_mse, results.tst_cost, results.tst_mse, alltree(bn), allfeat(bn), tree.newtree(bn), tree.newfeat(bn));
			if strcmp(pars.method,'ranking')%pars.rank_flag
				fprintf(' tra_ndcg: %f, val_ndcg: %f, tst_ndcg: %f\n', results.tra_ndcg, results.val_ndcg, results.tst_ndcg);
			elseif strcmp(pars.method,'classification')
				fprintf(' tra_err: %f, val_err: %f, tst_err: %f\n', results.tra_err, results.val_err, results.tst_err);
			end

			% remain
			remain(bn) = sum(results.tst_partition(bn,:))/ntst;
			
			if curdepth < pars.depth
				% set node t threshold
				mmin = min(results.tra_preds);
				mmax = max(results.tra_preds);
			    while mmin < mmax - 1e-06
			            trytry = (mmin+mmax)/2;
						dd = sum(results.tra_preds(logical(results.tra_partition(bn,:))) - trytry > 0)/(sum(results.tra_partition(bn,:))+1);
			            if abs(dd-pars.keep)/pars.keep < 1e-1
			                    theta(bn) = trytry;
			                    break; 
			            elseif dd > pars.keep
			                    mmin = trytry;
			            else
			                    mmax = trytry;
			            end
			    end
				if abs(dd-pars.keep)/pars.keep >= 1e-1
					theta(bn) = -10;
				end

				% set probability
				Tree(bn,3) = count+1; 	Tree(count+1,end) = bn; 	Tree(count+1,1) = Tree(bn,1) + 1;
				Tree(bn,4) = count+2;	Tree(count+2,end) = bn;		Tree(count+2,1) = Tree(bn,1) + 1;
	
				tree.nodeprob(count+1,:) = tree.nodeprob(bn,:).*sig(W(bn,:)*data.xtr-theta(bn));
				tree.nodeprob(count+2,:) = tree.nodeprob(bn,:).*(1-sig(W(bn,:)*data.xtr-theta(bn)));
		
				tree.nodeprob_sepa(count+1,:) = sig(W(bn,:)*data.xtr-theta(bn));
				tree.nodeprob_sepa(count+2,:) = 1-sig(W(bn,:)*data.xtr-theta(bn));
		
				results.tra_partition(count+1,:) = results.tra_partition(bn,:).*(W(bn,:)*data.xtr > theta(bn));
				results.tra_partition(count+2,:) = results.tra_partition(bn,:).*(W(bn,:)*data.xtr <= theta(bn));
	
				results.val_partition(count+1,:) = results.val_partition(bn,:).*(W(bn,:)*data.xtv > theta(bn));
				results.val_partition(count+2,:) = results.val_partition(bn,:).*(W(bn,:)*data.xtv <= theta(bn));
	
				results.tst_partition(count+1,:) = results.tst_partition(bn,:).*(W(bn,:)*data.xte > theta(bn));
				results.tst_partition(count+2,:) = results.tst_partition(bn,:).*(W(bn,:)*data.xte <= theta(bn));
			
				% new nodes
				newchildren = [newchildren,count+1,count+2];
	
				%free feature
				tree.fnotused(count+1,:) = tree.fnotused(bn,:).*((data.F*(W(bn,1:end-1)~=0)')==0)';
				tree.fnotused(count+2,:) = tree.fnotused(bn,:).*((data.F*(W(bn,1:end-1)~=0)')==0)';
		
				%free trees
				tree.tnotused(count+1,:) = tree.tnotused(bn,:).*(W(bn,1:end-1)==0);
				tree.tnotused(count+2,:) = tree.tnotused(bn,:).*(W(bn,1:end-1)==0);
		
				count = count+1;
			end
		end	
		curdepth = curdepth + 1;
	end
	
	if (pars.prune)
		disp('##################################prunning##################################');
		numnodes = 2^(pars.depth)-1;
		newactivenodes = [2^(pars.depth-1):2^pars.depth-1];
		notprunned = [1:2^pars.depth-1];
		largediff = 99999;
		tst_score = results.tst_preds;
		if strcmp(pars.method,'ranking')%pars.rank_flag
			selectperf = results.val_ndcg;
		elseif strcmp(pars.method,'classification')
			selectperf = 1-results.val_err;
		elseif strcmp(pars.method,'regression')
			selectperf = -results.val_mse;
		else
			error('pars.method type not yet implemented');
		end
		val_score = zeros(1,nval);
		while (largediff>0 | numnodes > pars.min_nodes)
			largediff = -99999;
			bestperf = selectperf;
			activenodes = newactivenodes;
			for an = activenodes
				anparent = Tree(an,6);
				val_score = results.val_preds;
				val_score(logical(results.val_partition(an,:))) = W(anparent,:)*data.xtv(:,logical(results.val_partition(an,:)));
				if strcmp(pars.node_eval, 'ndcg')
					perf = ndcg(val_score,data.valqs,data.ytv,5, 10);
				elseif strcmp(pars.node_eval, 'mse')
					perf = -mean((val_score-data.ytv).^2);
				elseif strcmp(pars.node_eval, 'err')
					val_p = val_score;
					val_p(val_p >= 0.5) = 1;
					val_p(val_p <  0.5) = 0;
					perf = 1-mean(val_p ~= data.ytv); % accuracy because maximized
				else
					error('pars.node_eval type not yet implemented');
				end
				if (perf - bestperf > largediff & an>2)
					largediff = perf - bestperf;
					bestnode = an;	
					selectperf = perf;			
				end
			end
			tst_score(logical(results.tst_partition(bestnode,:))) = W(Tree(bestnode,6),:)*data.xte(:,logical(results.tst_partition(bestnode,:)));
			if strcmp(pars.node_eval, 'ndcg')
				tst_perf = ndcg(tst_score,data.tstqs,data.yte,5, 10);
				fprintf('prunned: node %d, val_ndcg %f, val_mse %f, tst_cost %f, tst_ndcg %f, tst_mse %f\n',bestnode, selectperf, mean((val_score-data.ytv).^2), sum(Tree(:,2)), tst_perf, mean((tst_score-data.yte).^2));
			elseif strcmp(pars.node_eval, 'mse')
				tst_perf = mean((tst_score-data.yte).^2);
				fprintf('prunned: node %d, val_mse %d, tst_cost %f, tst_mse %d\n',bestnode, -selectperf, sum(Tree(:,2)), tst_perf);
			elseif strcmp(pars.node_eval, 'err')
				tst_p = tst_score;
				tst_p(tst_p >= 0.5) = 1;
				tst_p(tst_p <  0.5) = 0;
				tst_perf = 1-mean(tst_p ~= data.yte); 
			else
				error('pars.node type not yet implemented');
			end
			% prune
			results.val_preds(logical(results.val_partition(bestnode,:))) = W(Tree(bestnode,6),:)*data.xtv(:,logical(results.val_partition(bestnode,:)));
			ind = find(activenodes==bestnode);
			newactivenodes = activenodes;
			if (ismember(Tree(bestnode,6),newactivenodes) | (Tree(Tree(bestnode,6),3) ~= bestnode & ismember(Tree(Tree(bestnode,6),3),notprunned)) | ...
				(Tree(Tree(bestnode,6),4) ~= bestnode & ismember(Tree(Tree(bestnode,6),4),notprunned)))
				newactivenodes(ind) = [];
				pind = find(notprunned==bestnode);
				notprunned(pind) = [];
			else
				newactivenodes(ind) = Tree(bestnode,6);
			end
			numnodes = numnodes - 1;
			recover = Tree(bestnode,:);
			Tree(bestnode,:) = 0;
			if numnodes == pars.min_nodes & largediff<0
				disp([num2str(pars.min_nodes) ' nodes break'])
				break;
			end
		end

		if numnodes < pars.min_nodes
			disp('aggressive break')
			Tree(bestnode,:) = recover;
		end
	end
	
	disp('##################################re-optimization##################################');
	% retriving tree structure
	tree.parentnodes = zeros(2^pars.depth-1,2^pars.depth-1); % indicator matrix of parent nodes for each node
	tree.descendants = zeros(2^pars.depth-1,2^pars.depth-1); % indicator matrix of child nodes for each node
	tree.parentnodes = logical(tree.parentnodes);
	tree.descendants = logical(tree.descendants);
	alivenode = []; 

	for i = 1:2^pars.depth -1
		if (Tree(i,end)~=0 | Tree(i,1)==1) & sum(tree.nodeprob(i,:))~=0
			alivenode = [alivenode,i];
			tree.parentnodes(i,i) = true;
			iup = i;
			while(iup~=1)
				tree.descendants(iup,iup) = true;
				iup = Tree(iup,end); tree.parentnodes(i,iup) = true;
				tree.descendants(iup,i) = true;
			end
			tree.parentnodes(i,1) = true;
		end
	end
	tree.descendants(1,1) = true;
	
	% path
	tree.allpath = []; % matrix of paths to each leaf node
	for i = alivenode
		if Tree(i,3) ~= 0
			if Tree(Tree(i,3),1)==0 | Tree(Tree(i,4),1)==0 & sum(tree.nodeprob(i,:))~=0
				tree.allpath = [tree.allpath; tree.parentnodes(i,:)];
				if Tree(Tree(i,3),1)==0 & Tree(Tree(i,4),1)==0
					Tree(i,5) = 1;	% leaf node
				else
					Tree(i,5) = 2;  % prediction gating node
				end
			end
		else
			if Tree(i,3) == 0 & Tree(i,4) == 0
				Tree(i,5) = 1;
				tree.allpath = [tree.allpath; tree.parentnodes(i,:)];
			end
		end		 
	end

	
	% keyboard
	% maxiter = 3; 
	% subiter = 10;
	prevnodeloss = ones(2^pars.depth-1,1)*9999999;
	prev_idxw = ones(2^pars.depth-1,d+1);

	
	for iter = 1:pars.reopt_maxiter
		results.tra_cost = 0; results.totalloss = 0; results.tst_cost = 0; results.val_cost = 0; remaincount=0;
		for t = alivenode
			remaincount = remaincount+1;
			threshold = 1e-03;
			Wt = W(t,:);
			% intermediate node
			if Tree(t,5) ~= 1
				[leftleaves,rightleaves,patht] = child_paths(tree,t,Tree);
				gating_sigmas = zeros(length(data.cost),length(patht));
				idx_sigmas = gating_sigmas;
				prev_idx = ones(1,length(Wt));
				thetat = theta(t);

				for i = 1:pars.reopt_subiter
					idx_w = (abs(Wt(1:end-1))>threshold);
					idx_w = [idx_w,true];
					Wt(~idx_w) = 0;
					
					W(t,:) = Wt;
					[gating_sigmas, idx_sigmas, keta,idx_keta, etas, dl, lastnode] = update_var_and_prob(data, pars, tree, Wt, t, W, lambda, patht, leftleaves, rightleaves, idx_w, gating_sigmas, idx_sigmas, Tree);
					
					Wttheta = [Wt,thetat];

					[Wttheta,minloss] = minimize(Wttheta', @inner_loss_grad, 10, data, pars, tree, t, W, lambda, patht, leftleaves, rightleaves, idx_w, gating_sigmas, idx_sigmas, keta, idx_keta, etas, bestrho, Tree, lastnode);
					Wt = Wttheta(1:end-1)';
					thetat = Wttheta(end); 	
					gatingloss = minloss(end);
					
					% update nodeprobability
					% left ~ 0
					tree.nodeprob_sepa(Tree(t,3),:) = sig(Wt*data.xtr-thetat);
					% right ~ 1
					tree.nodeprob_sepa(Tree(t,4),:) = 1-sig(Wt*data.xtr-thetat);
					
					fprintf('node: %d, subiter: %d, gatingloss: %f, idx_w: %d\n',t,i,gatingloss,sum(idx_w));
					% termination criteria
					if sum(idx_w) == 1
						break;
					end
					if gatingloss <= prevnodeloss(t) & ((prevnodeloss(t) - gatingloss)/gatingloss < 1e-03 | gatingloss < 1e-04) & sum(idx_w) <= sum(prev_idxw(t,:)) & sum(idx_w ~= prev_idxw(t,:))/sum(idx_w) < 0.05
						break;
					end
					prevnodeloss(t) = gatingloss;
					prev_idxw(t,:) = idx_w;	
					W(t,:) = Wt;			
				end
				% update loss, here only the L1 norm, the path mixed norm is calculated with experts.
				[temp,temp,gatingreg] = inner_loss_grad(Wttheta, data, pars, tree, t, W, lambda, patht, leftleaves, rightleaves, idx_w, gating_sigmas, idx_sigmas, keta, idx_keta, etas, bestrho, Tree, lastnode);
				results.totalloss = results.totalloss + gatingreg;
				W(t,:) = Wt;
				theta(t) = thetat;
				
				% set prob
				tree.nodeprob(Tree(t,3),:) = tree.nodeprob(t,:).*sig(W(t,:)*data.xtr-theta(t));
				tree.nodeprob(Tree(t,4),:) = tree.nodeprob(t,:).*(1-sig(W(t,:)*data.xtr-theta(t)));
		
				tree.nodeprob_sepa(Tree(t,3),:) = sig(W(t,:)*data.xtr-theta(t));
				tree.nodeprob_sepa(Tree(t,4),:) = 1-sig(W(t,:)*data.xtr-theta(t));
				
				% setting the split thing
				results.tra_partition(Tree(t,3),:) = results.tra_partition(t,:).*(W(t,:)*data.xtr > theta(t));
				results.tra_partition(Tree(t,4),:) = results.tra_partition(t,:).*(W(t,:)*data.xtr <= theta(t));
			
				results.tra_cost = results.tra_cost + sum(results.tra_partition(t,:))/n * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');
				%it's the real cost, that's why we do l_0 norm
			
				% testing
				results.tst_partition(Tree(t,3),:) = results.tst_partition(t,:).*(W(t,:)*data.xte > theta(t));
				results.tst_partition(Tree(t,4),:) = results.tst_partition(t,:).*(W(t,:)*data.xte <= theta(t));
				results.tst_cost = results.tst_cost + sum(results.tst_partition(t,:))/ntst * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');
			
				%free feature
				tree.fnotused(Tree(t,3),:) = tree.fnotused(t,:).*((data.F*(Wt(1:end-1)~=0)')==0)';
				tree.fnotused(Tree(t,4),:) = tree.fnotused(t,:).*((data.F*(Wt(1:end-1)~=0)')==0)';
				
				%free trees
				tree.tnotused(Tree(t,3),:) = tree.tnotused(t,:).*(W(t,1:end-1)==0);
				tree.tnotused(Tree(t,4),:) = tree.tnotused(t,:).*(W(t,1:end-1)==0);
				
				% predictions
				results.tra_preds(logical(results.tra_partition(t,:))) = W(t,:)*data.xtr(:,logical(results.tra_partition(t,:)));	
				% tst_predind = (results.tst_partition(t,:) == 1);
				results.tst_preds(logical(results.tst_partition(t,:))) = W(t,:)*data.xte(:,logical(results.tst_partition(t,:)));	
				
				tra_remain(remaincount) = (results.tra_partition(Tree(t,3),:)*pars.wtra')/sum(pars.wtra);
				
				% validation
				results.val_partition(Tree(t,3),:) = results.val_partition(t,:).*(W(t,:)*data.xtv > theta(t));
				results.val_partition(Tree(t,4),:) = results.val_partition(t,:).*(W(t,:)*data.xtv <= theta(t));
				results.val_cost = results.val_cost + sum(results.val_partition(t,:))/nval * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');
				results.val_preds(logical(results.val_partition(t,:))) = W(t,:)*data.xtv(:,logical(results.val_partition(t,:)));	
				
			else
				% lasso
				transxtr = (bsxfun(@times,data.xtr,sqrt(prod(tree.nodeprob_sepa(tree.parentnodes(t,:),:),1)).*(pars.wtra.^.5)))/sqrt(sum(pars.wtra));
				transytr = data.ytr.*sqrt(prod(tree.nodeprob_sepa(tree.parentnodes(t,:),:),1)).*(pars.wtra.^.5)/sqrt(sum(pars.wtra));
				
				% solving it using alternating algo.
				for i = 1:pars.reopt_subiter
					
					idx_w = (abs(Wt(1:end-1))>threshold);
					idx_w = [idx_w,true];
			
					W(t,:) = Wt;

					eta = abs(Wt(idx_w(1:end-1)));
					dk = [];
					for k = find(tree.parentnodes(t,:)~=0)
						dk = [dk,sum(prod(tree.nodeprob_sepa(tree.parentnodes(k,:),:),1).*pars.wtra)/sum(pars.wtra)];
					end
					patht = find(tree.allpath(:,t) == 1);
							
					sigma = sqrt(sum(data.F.^2*(W(logical(tree.allpath(patht,:)),1:end-1)').^2,2));
					idx_sig = sigma~=0;
					
					keta = sqrt(sum((W(tree.parentnodes(t,:),1:end-1)').^2,2));
					idx_keta = keta~=0;	
										
					expertloss = sum((transytr - Wt*transxtr).^2) + lambda * dk(end) * (data.cost(idx_sig) * sigma(idx_sig) + sum(keta(idx_keta))) + bestrho * sum(abs(Wt(idx_w(1:end-1))));

					fprintf('node: %d, subiter: %d, nodeloss: %f, idx_w: %d\n',t,i,expertloss,sum(idx_w));

					% termination criteria
					if i > pars.reopt_subiter
						break;
					end
					if sum(idx_w) == 1 | sum(idx_w) == 0
						break;
					end
					if sum(idx_w) <= sum(prev_idxw(t,:)) & sum(idx_w ~= prev_idxw(t,:))/sum(idx_w) < 0.05 & expertloss <= prevnodeloss(t) & (prevnodeloss(t) - expertloss)/expertloss < 1e-05 
						break;
					end
					if dk(end) == 0;
						break;
					end
					prev_idxw(t,:) = idx_w; prevnodeloss(t) = expertloss;	
					
					% closed-form
					Wt_res = (transxtr(idx_w,:)*transxtr(idx_w,:)' + ...
						diag([.5*bestrho*(ones(1,sum(idx_w)-1)./eta),0]) + ...
						0.5*lambda*dk(end)*diag([data.cost(idx_sig)./sigma(idx_sig)'*data.F(idx_sig,idx_w(1:end-1))+(1./keta(idx_w(1:end-1)))',0]))\(transxtr(idx_w,:)*transytr'); 
					
					Wt(:) = 0;
					Wt(idx_w) = Wt_res;
					W(t,:) = Wt;	
				end	
				results.totalloss = results.totalloss + expertloss;		
				results.tra_cost  = results.tra_cost + sum(results.tra_partition(t,:))/n    * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');
				results.tst_cost  = results.tst_cost  + sum(results.tst_partition(t,:))/ntst * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');	
				results.val_cost  = results.val_cost  + sum(results.val_partition(t,:))/nval * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');
				
				% predictions
				results.tra_preds(logical(results.tra_partition(t,:))) = W(t,:)*data.xtr(:,logical(results.tra_partition(t,:)));	
				results.tst_preds(logical(results.tst_partition(t,:))) = W(t,:)*data.xte(:,logical(results.tst_partition(t,:)));	
				results.val_preds(logical(results.val_partition(t,:))) = W(t,:)*data.xtv(:,logical(results.val_partition(t,:)));	
								                                                                   			
			end % if leave nodes	

		end % alivenode	
		
		fprintf('alivenode: ');
		fprintf(' %d ', alivenode);
		fprintf('\n');
		fprintf('remain: ');
		fprintf(' %2.4f ', tra_remain);
		fprintf('\n');
		
		if strcmp(pars.method,'ranking')%pars.rank_flag
			results.tra_ndcg = ndcg(results.tra_preds,data.traqs,data.ytr,5, 10);
			results.tst_ndcg = ndcg(results.tst_preds,data.tstqs,data.yte,5, 10);
			results.val_ndcg = ndcg(results.val_preds,data.valqs,data.ytv,5, 10);
		elseif strcmp(pars.method,'classification')
			tra_p = results.tra_preds;
			tra_p(tra_p >= 0.5) = 1;
			tra_p(tra_p <  0.5) = 0;
			results.tra_err = mean(tra_p ~= data.ytr);  	
			val_p = results.val_preds;
			val_p(val_p >= 0.5) = 1;
			val_p(val_p <  0.5) = 0;
			results.val_err = mean(val_p ~= data.ytv);
			tst_p = results.tst_preds;
			tst_p(tst_p >= 0.5) = 1;
			tst_p(tst_p <  0.5) = 0;
			results.tst_err = mean(tst_p ~= data.yte);
		end
		results.tra_mse = mean((results.tra_preds-data.ytr).^2);
		results.tst_mse = mean((results.tst_preds-data.yte).^2);
		results.val_mse = mean((results.val_preds-data.ytv).^2);
		fprintf(' *********** round %d results *************\n',iter);
		fprintf('round: %d, loss: %f, tra_cost: %f, tra_mse: %f, val_cost: %f, val_mse: %f, tst_cost: %f, tst_mse: %f\n', iter, results.totalloss,...
			results.tra_cost, results.tra_mse, results.val_cost, results.val_mse, results.tst_cost, results.tst_mse);
		if strcmp(pars.method,'ranking')%pars.rank_flag
			fprintf('tra_ndcg: %f, val_ndcg: %f, tst_ndcg: %f\n', results.tra_ndcg, results.val_ndcg, results.tst_ndcg);				
		elseif strcmp(pars.method,'classification')
			fprintf('tra_err: %f, val_err: %f, tst_err: %f\n', results.tra_err, results.val_err, results.tst_err);	
		end
		fprintf(' *********** round results *************\n')	
	
		% termination criteria
		if results.totalloss <= prevloss & (prevloss-results.totalloss)/results.totalloss < 1e-05
			break;
		end
		prevloss = results.totalloss;
		
	end		
	
	save(['results/prune_opt_lambda_no_fine_tune',num2str(pars.lambda0),'_keep',num2str(pars.keep),'_',pars.method,'.mat'],'W','Tree','-v7.3');	
	timeopt = toc;
	fprintf('globalopt time: %f\n',timeopt);
	tic;
	
	
	disp('##################################fine-tunning##################################');
	if strcmp(pars.method,'ranking')%pars.rank_flag
		bestperf_val = results.val_ndcg;
	elseif strcmp(pars.method,'classification')
		bestperf_val = 1-results.val_err;
	elseif strcmp(pars.method,'regression')
		bestperf_val = -results.val_mse;
	else
		error('pars.method type not yet implemented');
	end
	% maxiter = 1; 
	% subiter = 10;
	for iter = 1:pars.finetune_maxiter
		results.tra_cost = 0; results.totalloss = 0; results.tst_cost = 0; results.val_cost = 0;
		for t = alivenode
			threshold = 1e-03;
			Wt = W(t,:);
			% pure gating nodes
			if Tree(t,5) == 0 | sum(tree.nodeprob(t,:)) <= 1e-03
				results.tra_cost  = results.tra_cost + sum(results.tra_partition(t,:))/n    * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');
				results.tst_cost  = results.tst_cost  + sum(results.tst_partition(t,:))/ntst * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');	
				results.val_cost  = results.val_cost  + sum(results.val_partition(t,:))/nval * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');									
			else
				% lasso
				transxtr = (bsxfun(@times,data.xtr,sqrt(prod(tree.nodeprob_sepa(tree.parentnodes(t,:),:),1)).*(pars.wtra.^.5)))/sqrt(sum(pars.wtra));
				transytr = data.ytr.*sqrt(prod(tree.nodeprob_sepa(tree.parentnodes(t,:),:),1)).*(pars.wtra.^.5)/sqrt(sum(pars.wtra));
				
				transXX = transxtr*transxtr';
				transXY = transxtr*transytr';
				% for leaves nodes, tune rho
				[Wt,expertrho,expertloss] = tune_fine_tune(data, pars, tree, results, transXX, transXY, transytr, transxtr, Tree, t, W(t,:), W, d, pathroot, lambda, curdepth, nval, bestperf_val);
				W(t,:) = Wt;
				
				results.totalloss = results.totalloss + expertloss;		
				results.tra_cost  = results.tra_cost + sum(results.tra_partition(t,:))/n    * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');
				results.tst_cost  = results.tst_cost  + sum(results.tst_partition(t,:))/ntst * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');	
				results.val_cost  = results.val_cost  + sum(results.val_partition(t,:))/nval * (tree.fnotused(t,:).*data.cost*((data.F*(Wt(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wt(1:end-1)~=0)');
								
				% predictions
				results.tra_preds(logical(results.tra_partition(t,:))) = W(t,:)*data.xtr(:,logical(results.tra_partition(t,:)));	
				results.tst_preds(logical(results.tst_partition(t,:))) = W(t,:)*data.xte(:,logical(results.tst_partition(t,:)));	
				results.val_preds(logical(results.val_partition(t,:))) = W(t,:)*data.xtv(:,logical(results.val_partition(t,:)));				                                                                   			
			end % if leave nodes		
		end % alivenode	
		
		if strcmp(pars.method,'ranking')%pars.rank_flag
			results.tra_ndcg = ndcg(results.tra_preds,data.traqs,data.ytr,5, 10);
			results.tst_ndcg = ndcg(results.tst_preds,data.tstqs,data.yte,5, 10);
			results.val_ndcg = ndcg(results.val_preds,data.valqs,data.ytv,5, 10);
		elseif strcmp(pars.method,'classification')
			tra_p = results.tra_preds;
			tra_p(tra_p >= 0.5) = 1;
			tra_p(tra_p <  0.5) = 0;
			results.tra_err = mean(tra_p ~= data.ytr);  	
			val_p = results.val_preds;
			val_p(val_p >= 0.5) = 1;
			val_p(val_p <  0.5) = 0;
			results.val_err = mean(val_p ~= data.ytv);
			tst_p = results.tst_preds;
			tst_p(tst_p >= 0.5) = 1;
			tst_p(tst_p <  0.5) = 0;
			results.tst_err = mean(tst_p ~= data.yte);
		end
	
		results.tra_mse = mean((results.tra_preds-data.ytr).^2);
		results.tst_mse = mean((results.tst_preds-data.yte).^2);
		results.val_mse = mean((results.val_preds-data.ytv).^2);
		fprintf(' *********** fine-tuning round %d results *************\n',iter);
		if strcmp(pars.method,'ranking')%pars.rank_flag
			fprintf('round: %d, loss: %f, tra_cost: %f, tra_mse: %f, tra_ndcg: %f, val_cost: %f, val_mse: %f, val_ndcg: %f, tst_cost: %f, tst_mse: %f, tst_ndcg: %f\n',iter,results.totalloss,...
				results.tra_cost, results.tra_mse, results.tra_ndcg, results.val_cost, results.val_mse, results.val_ndcg, results.tst_cost, results.tst_mse, results.tst_ndcg);
		elseif strcmp(pars.method,'classification')	
			fprintf('round: %d, loss: %f, tra_cost: %f, tra_err: %f, val_cost: %f, val_err: %f, tst_cost: %f, tst_err: %f\n',iter,results.totalloss,...
				results.tra_cost, results.tra_err, results.val_cost, results.val_err, results.tst_cost, results.tst_err);
		elseif strcmp(pars.method,'regression')
			fprintf('round: %d, loss: %f, tra_cost: %f, tra_mse: %f, val_cost: %f, val_mse: %f, tst_cost: %f, tst_mse: %f\n',iter,results.totalloss,...
				results.tra_cost, results.tra_mse, results.val_cost, results.val_mse, results.tst_cost, results.tst_mse);
		else
			error('pars.method type not yet implemented');
		end
		fprintf(' *********** fine-tuning round results *************\n')	
	
		% termination criteria
		if results.totalloss <= prevloss & (prevloss-results.totalloss)/results.totalloss < 1e-05
			break;
		end
		prevloss = results.totalloss;
		
	end		
	
	timefine = toc;
	fprintf('globalfine time: %f\n',timefine);	
	
	
	
	
	
end
