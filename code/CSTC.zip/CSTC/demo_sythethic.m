clear all;
clc;
setpaths
fprintf('Loading data ...\n');
load('data/artificial_split.mat');
% Contents:
% ---------
% F - (d,T) an indicator design matrix of features used in different weak learners
% cost - (d,1) feature cost
% traqs - (n,1) training query ids
% valqs - validation query ids
% tstqs - test query ids
% xtr - (d,n) training data
% xtv - validation data
% xte - test data
% ytr - (1,n) training labels
% ytv - validation labels
% yte - test labels
data.F = F;
data.cost = cost;
data.xtr = xtr;
data.xtv = xtv;
data.xte = xte;
data.ytr = ytr;
data.ytv = ytv;
data.yte = yte;

[results, tree, Tree, W] = cstc(data,'lambda0',1e-05,'keep',0.5,'depth',3,'method','classification','node_eval','mse','rhos',[.2:.1:.9,1:6]);
