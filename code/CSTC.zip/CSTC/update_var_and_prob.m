function [sigmas,idx_sigmas,keta,idx_keta,etas,dl,lastnodereturn]=update_var_and_prob(data, pars, tree, Wt, t, Wall, lambda, patht, leftleaves, rightleaves, idx_w, sigmas, idx_sigmas, Tree)
% UPDATE_VAR_AND_PROB (ALTER_CSTCPRUNE_PRECOMPUTE): Update auxiliary variables used in node optimization and compute conditional probability of reaching
%							  each leaf node in paths that pass through node t.
%
% INPUTS
%	data - a struct containing all data (see runYahoo.m for an example)
%	pars - a struct of parameter settings
%	tree - a struct of CSTC information
%	Wt - parameters of current node t
%	t - index of node t being optimized
%	Wall - parameter matrix of all nodes
%	lambda - accuracy/cost trade-off parameter
%	patht - indices of paths that node t is in
%	leftleaves - path starting with left (upper) child of node t
%	rightleaves - path startin with right (lower) child of node t
%	idx_w - indicator vector of non-zero elements of Wt
%	sigmas - auxiliary variable for feature cost term for node t
%	idx_sigmas - indicator vector of non-zero sigmas for node t
%	Tree - tree information matrix
%
% OUTPUTS
%	sigmas - see above.
%	idx_sigmas - see above.
%	keta - auxiliary variable for evaluation cost term for node t
%	idx_keta - indicator vector of non-zero ketas for node t
%	etas - auxiliary variable for l1 term, node t
%	dl - a list of the conditional probability of any input reaching a leaf node from their parent node in paths through t
%	lastnodereturn - the leaf nodes of all paths containing node t

	oldpath = tree.allpath;
	tree.allpath(:,t) = 0;	% don't include node t
	ind = 1;
	
	% loop through paths that have node t
	for tt = patht'

		% get last node of each path
		findlastnode = find(oldpath(tt,:));
		lastnode = findlastnode(end);
		lastnodereturn(ind) = lastnode;
		
		% compute conditional probability for any input reaching a leaf node from their parent node
		if (Tree(lastnode,3)==0 & Tree(lastnode,4)==0)
			dl(ind) = sum(prod(tree.nodeprob_sepa(tree.parentnodes(lastnode,:),:),1).*pars.wtra)/sum(pars.wtra);
		else if Tree(Tree(lastnode,3),1)==0
				dl(ind) = sum(prod(tree.nodeprob_sepa(tree.parentnodes(lastnode,:),:),1).*tree.nodeprob_sepa(Tree(lastnode,3),:).*pars.wtra)/sum(pars.wtra);
			else 
				dl(ind) = sum(prod(tree.nodeprob_sepa(tree.parentnodes(lastnode,:),:),1).*tree.nodeprob_sepa(Tree(lastnode,4),:).*pars.wtra)/sum(pars.wtra);
			end
		end			
		
		% auxiliary variable for feature cost
		sigmas(:,ind) = dl(ind) * sqrt(sum(data.F.^2*([Wall(logical(tree.allpath(tt,:)),1:end-1);Wt(1:end-1)]').^2,2));
		idx_sigmas(:,ind) = sigmas(:,ind)~=0;

		% auxiliary variable for evaluation cost
		keta(:,ind) = dl(ind) * sqrt(sum(([Wall(logical(tree.allpath(tt,:)),1:end-1);Wt(1:end-1)]').^2,2));
		idx_keta(:,ind) = keta(:,ind)~=0;
		
		ind = ind+1;
	end
	
	% auxiliary variable for l1 term
	etas = abs(Wt(idx_w(1:end-1)));
end
