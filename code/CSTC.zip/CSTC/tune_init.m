function [bestWt,bestrho] = tune_init(data, pars, tree, results, transXX, transXY, transytr, transxtr, Tree, t, Wt, W, d, pathroot, lambda, curdepth, nval)
% TUNE_INIT (was tune) Tunes the parameter rho, controlling the l1-regularization trade-off
%
% INPUT
%	data - a struct containing all data (see runYahoo.m for an example)
%	pars - a struct of parameter settings
%	tree - a struct of CSTC information
%	results - a struct of train/validation/test information
%	transXX - data matrix X * data matrix X * probability of reaching node t from parent * normalized instance weights
%	transXY - data matrix X * label vector Y * probability of reaching node t from parent * normalized instance weights
%	transytr - label vector Y * sqrt(probability of reaching node t from parent) * sqrt(normalized instance weights)
%	transxtr - data matrix X * sqrt(probability of reaching node t from parent) * sqrt(normalized instance weights)
%	Tree - tree information matrix
%	t - index of node being fine-tuned
%	Wt - parameters of current node t
%	W - parameter matrix of all nodes
%	d - number of weak learners
%	pathroot - indices of nodes on path from root to node t
%	lambda - accuracy/cost trade-off parameter
%	curdepth - depth of node t in the tree
%	ntst - number of test points
%
% OUTPUT
%	bestWt - optimized parameters of current node t
%	bestrho - best l1-regularization trade-off parameter
	if strcmp(pars.node_eval, 'ndcg') 
		bestperf = 0;
	elseif strcmp(pars.node_eval, 'mse')
		bestperf = -Inf;
	elseif strcmp(pars.node_eval, 'err')
		bestperf = 0;
	else
		error('pars.node_eval type not yet implemented');
	end
	
	for rho = pars.rhos
		
		threshold = 1e-03;
		% preparation for optimization initialization
		prevloss = Inf;
		prev_idxw = ones(1,d+1);
		maxiter = 100;
		Wct = Wt;
		Wc = W;
		i = 1;

		% solving it using alternating algo.
		while true
			idx_w = (abs(Wct(1:end-1)) > threshold);
			idx_w = [idx_w,true];
			Wct(~idx_w) = 0;	
			Wc(t,:) = Wct;
			
			eta = abs(Wct(idx_w(1:end-1)));
			dk = [];
			for k = pathroot
				dk = [dk,sum(tree.nodeprob(k,:).*pars.wtra)/sum(pars.wtra)];
			end		
			% keta for the path
			keta = sqrt((Wc(pathroot,1:end-1)').^2 * (dk.^2)');
			idx_keta = keta~=0;		
			% sigma for the path
			sigma = sqrt(sum(bsxfun(@times,data.F.^2*(Wc(pathroot,1:end-1)').^2,(dk.^2)),2));
			idx_sig = sigma~=0;	

			expertloss = sum((transytr - Wct*transxtr).^2) + lambda * (data.cost(idx_sig) * sigma(idx_sig) + sum(keta(idx_keta))) +...
				 		(rho) * sum(abs(Wct(idx_w(1:end-1))));
				
			% termination criteria
			if i > maxiter
				break;
			end
			if sum(idx_w) == 1
				break;
			end
			if sum(idx_w) <= sum(prev_idxw) & sum(idx_w ~= prev_idxw)/sum(idx_w) < 0.05 & expertloss <= prevloss & (prevloss - expertloss)/expertloss < 1e-05 
				break;
			end
			prev_idxw = idx_w; prevloss = expertloss;	
					
			% closed-form
			Wct_res = (transXX(idx_w,idx_w) + ...
				diag([.5*(rho)*(ones(1,sum(idx_w)-1)./eta),0]) + ...
				0.5*lambda*dk(1)*dk(1)*diag([(1./keta(idx_w(1:end-1)))' + data.cost(idx_sig)./sigma(idx_sig)'*data.F(idx_sig,idx_w(1:end-1)),0]))\(transXY(idx_w)); 
			
			
			Wct(:) = 0;
			Wct(idx_w) = Wct_res;
			i = i + 1;
		end	
		
		newtree = sum(Wct~=0);
		newfeat = sum((data.F*(Wct(1:end-1)~=0)')~=0);
		
		% compute validation performance
		results.val_preds(logical(results.val_partition(t,:))) = Wct*data.xtv(:,logical(results.val_partition(t,:)));
		if strcmp(pars.node_eval, 'ndcg')
			val_perf = ndcg(results.val_preds,data.valqs,data.ytv,5, 10);
			val_mse = -mean((results.val_preds-data.ytv).^2);
		elseif strcmp(pars.node_eval, 'mse')
			val_perf = -mean((results.val_preds-data.ytv).^2);
		elseif strcmp(pars.node_eval, 'err')
			disp('err eval!');
			val_p = results.val_preds;
			val_p(val_p >= 0.5) = 1;
			val_p(val_p <  0.5) = 0;
			val_perf = 1-mean(val_p ~= data.ytv); % accuracy because maximized
		else
			error('pars.node_eval type not yet implemented');
		end

		

		if (val_perf > bestperf)
			bestperf = val_perf;
			bestrho = rho;
			bestWt = Wct;
		end
		
		% compute validation cost
		cvcost = sum(results.val_partition(t,:))/nval * (tree.fnotused(t,:).*data.cost*((data.F*(Wct(1:end-1)~=0)')~=0) + tree.tnotused(t,:)*(Wct(1:end-1)~=0)'); 
		
		if strcmp(pars.node_eval, 'ndcg')
			fprintf('node: %d, depth: %d, rho: %f, val_cost: %f, val_ndcg: %f, val_mse: %f, trees: %d, feat: %d\n',...
				t, curdepth, rho, cvcost, val_perf, -val_mse, newtree, newfeat);
		elseif strcmp(pars.node_eval, 'mse')
			fprintf('node: %d, depth: %d, rho: %f, val_cost: %f, val_mse: %f, trees: %d, feat: %d\n',...
				t, curdepth, rho, cvcost, -val_perf, newtree, newfeat);
		elseif strcmp(pars.node_eval, 'err')
			fprintf('node: %d, depth: %d, rho: %f, val_cost: %f, val_err: %f, trees: %d, feat: %d\n',...
				t, curdepth, rho, cvcost, 1-val_perf, newtree, newfeat);
		else
			error('pars.node_eval type not yet implemented');
		end

	end
		
		
	
