function [leftleaves,rightleaves,patht] = child_paths(tree, t, Tree)
% CHILD_PATHS (was GATING_CSTCPRUNE_PRECOMPUTE) Obtain the paths beginning at the left (upper) and right (lower) children
%							   					of node t and the indices of the paths that path through it
%
% INPUTS
%	tree - a struct of CSTC information
%	t - index of node being fine-tuned
%	Tree - tree information matrix
%
% OUTPUTS
%	leftleaves - node indices of all descendants of left (upper) child of node t
%	rightleaves - node indices of all descendants of right (lower) child of node t
%	patht - indices of paths that node t is in

% find left child descendants
tleft = Tree(t,3);
if tleft == 0
	leftleaves = [];
else
	leftleaves = find(tree.descendants(tleft,:));
end

% find right child descendants
tright = Tree(t,4);
if tright == 0
	rightleaves = [];
else
	rightleaves = find(tree.descendants(tright,:));
end


% what paths is node t in?
patht = find(tree.allpath(:,t) == 1);

