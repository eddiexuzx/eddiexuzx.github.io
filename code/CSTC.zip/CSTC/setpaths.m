addpath(pwd);
addpath([pwd '/helperfunctions']);