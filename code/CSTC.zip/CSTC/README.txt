Cost-Sensitive Tree of Classifiers (ICML 2013, http://jmlr.org/proceedings/papers/v28/xu13.pdf)
Zhixiang (Eddie) Xu		xuzx@cse.wustl.edu
Matt J. Kusner			mkusner@wustl.edu
Kilian Q. Weinberger	kilian@wustl.edu
Minmin Chen				mchen@wustl.edu

The code cstc.m builds a Cost-Sensitive Tree of Classifiers that obtains a high-performance model (e.g. MSE, NDCG) within a test-time budget (e.g. CPU-cost, money).

Usage
-----
For a ranking example, run demo_yahoo.m
For a regression example, run demo_synthetic.m


Citing
------
If you use this code in scientific work, please cite:

@inproceedings{xu2013cost,
  title={Cost-Sensitive Tree of Classifiers},
  author={Xu, Zhixiang and Kusner, Matt and Chen, Minmin and Weinberger, Kilian Q},
  booktitle={Proceedings of the 30th International Conference on Machine Learning (ICML-13)},
  pages={133--141},
  year={2013}
}