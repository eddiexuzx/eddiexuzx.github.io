function [prec] = mse(preds, queries, targets, topX, NEGATIVE_EXAMPLES_WEIGHT)

	n = length(targets);
	prec = 1-sum(round(preds)~=targets)/n;
	% keyboard