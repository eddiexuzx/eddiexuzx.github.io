matlab code for GreedyMiser

Zhixiang (Eddie) Xu, Kilian Q. Weinberger, Olivier Chapelle
The Greedy Miser: Learning Under Test-time Budget
Proc. of 29th Intl. Conf. on Machine Learning (ICML), Edinburgh, 2012

RUN:
1. download some data with cost information
xtr, ytr: training inputs and labels, 
xtv, ytv: validation inputs and labels,
xte, yte: testing inputs and labels,
cost:     cost information
traqs:    for ranking data, training queries
valqs:	for ranking data, validation queries
tstqs:	  for testing data, testing queries

2. run greedymiser.m
lambda:	regularizer for cost
2.1.	for ranking data:
greedymiser(xtr,ytr,xtv,ytv,xte,yte,cost,lambda,traqs,valqs,tstqs) 



