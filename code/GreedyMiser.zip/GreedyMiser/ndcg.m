function [prec] = ndcg(preds, queries, targets, topX, NEGATIVE_EXAMPLES_WEIGHT)

cur = 1;
nq = 0;
avg = 0;
while cur < length(queries)
	q = queries(cur);
	temp = [preds(queries==q);targets(queries==q)];
	[sorted, ind] = sort(temp(1,:), 'descend');
	
	topTake = min(topX,size(temp,2));
	
	log2i = log2([1:topTake]+1);
    % log2i = [1,log2i];
	
	%take only the topX true labels
	topTakepredlabels = temp(2,ind(1:topTake));
	% negind = find(topTakepredlabels==0,1);
	% topTakepredlabels(negind:end) = 0;
	
	[sortedlabels] = sort(temp(2,:), 'descend');
	topTaketruelabels = sortedlabels(1:topTake);

	% DCG
	DCG = sum((2.^topTakepredlabels-1)./log2i);
	IDCG = sum((2.^topTaketruelabels-1)./log2i);
	
	% nDCG
	if (IDCG == 0)
	    nDCG = 1;
    else
        nDCG = DCG/IDCG;
    end
	avg = avg + nDCG;
    % if nq >= 39
    %         keyboard
    %     end
	cur = cur + size(temp, 2);
	nq = nq + 1;	
end

prec = avg/nq;
