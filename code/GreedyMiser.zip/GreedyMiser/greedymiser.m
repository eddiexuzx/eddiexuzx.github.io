function [beststep,tst_prec, val_prec, totalcost, totalfeat] = greedymiser(xtr,ytr,xtv,ytv,xte,yte,cost,lambda,traqs,valqs,tstqs)

% assume:
% xtr = dxn, ytr = 1xn, cost = 1xd, traqs = 1xn

% addpath to the CART tree generator, and make
addpath('mex_gen');
cd mex_gen
make
cd ..

% set params
options.learningrate=0.01;	% learning rate
options.depth=4;			% CART tree depth
options.ntrees = 3000;		% total number of CART trees
options.verbose = true;		
options.computefeaturecosts = @(e) computefeaturecosts(lambda,cost,e); 	% feature cost update function
% loss function, we have squared loss, logistic loss, squared hinge loss
% gbrt returns ensemble e. 
[e,l] = gbrt(xtr',@(p)sqrloss(ytr,p),options);	

% we evaluate at every 10 trees
alldims = [0:10:options.ntrees];
alldims(1) = 1;
tst_prec = zeros(1,length(alldims));
val_prec = zeros(1,length(alldims));

count = 1;
for dd=1:length(alldims)
	dim = alldims(dd);
	tempe = {e{1}(1:dim),e{2}(1:dim)};
	preds_tst = evalensemble(xte',tempe);
	preds_val = evalensemble(xtv',tempe);
	% we evaluate using average precision, for non-binary, please use ndcg.m, or non-ranking data, please use mse.m
	tst_prec(count) = avgprec(preds_tst',tstqs,yte,5, 10);
	val_prec(count) = avgprec(preds_val',valqs,ytv,5, 10);
	count = count+1;
end
% return total cost, and total feature, recorded at every 10 trees.
[totalcost,totalfeat] = calcost(e,cost);
totalcost = totalcost + [1:1:options.ntrees]';

% return the best number of trees based on validation set.
[~,beststep] = max(val_prec);
