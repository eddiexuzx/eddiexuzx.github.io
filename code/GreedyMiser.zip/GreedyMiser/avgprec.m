function [prec] = avgprec(preds, queries, targets, topX, NEGATIVE_EXAMPLES_WEIGHT)

cur = 1;
nq = 0;
avg = 0;
while cur < length(queries)
	q = queries(cur);
	temp = [preds(queries==q);targets(queries==q)];
	[sorted, ind] = sort(temp(1,:), 'descend');
	tt = (temp(2,ind)>0);
	tt = tt(1:min(topX, length(tt)));
	
	ind = find(tt==0, 1);
	if length(ind) == 0
		avg = avg + 1;
	else
		avg = avg + (ind-1)/topX;
	end
	%Wtt = [];
	%for i = 1:min(topX, length(tt))
	%	Wtt = [Wtt tt(i)];
	%	if tt(i) == 0
	%		Wtt = [Wtt repmat(tt(i), 1, NEGATIVE_EXAMPLES_WEIGHT-1)];
	%	end
	%end	
	%tt = Wtt;
	%avg = avg + mean(tt(1:min(topX, length(tt))));
	cur = cur + size(temp, 2);
	nq = nq + 1;	
end
prec = avg/nq;
