mex buildlayer_sqrimpurity_openmp.cpp CXXFLAGS="\$CXXFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp"
mex evalensemble_c.cpp